# fsociety
__WARNING: do not actually execute this. You will not be able to recover the files.__

This is intended to encrypt every bit of data in a unix filesystem using 256-bit AES with 
a self-destructing, randomly generated key.

Inspired by Mr. Robot

## S2E1:

![alt text](Imgur File)

### Dependencies:

* Python3
* pycrypto

```shell
sudo apt install python3 python3-pip
```
```shell
pip3 install pycrypto
```

### Usage:

```shell
curl 
```
```shell
sudo chmod +x W0RM.py
```
```shell
./W0RM.py
```
